import React, {useMemo, useState} from "react";
import {createRoot} from "react-dom/client";
import {LayoutDashboard, Truck, Building2, Croissant, ReceiptText, WalletCards, Users, Package, BarChart3, Plus, Search, Bell, Download, Trash2, Menu, X, ChevronDown} from "lucide-react";
import "./styles.css";
import { cloudEnabled, signIn, signUp, signOut, supabase } from "./supabase";

const TABLES={companies:"companies",products:"products",deliveries:"deliveries",invoices:"invoices",expenses:"expenses",staff:"staff_wages",suppliers:"suppliers",cashEntries:"cash_entries",stock:"stock",payments:"payments"};

async function loadCloud(){
  if(!supabase) return null;
  const {data:{session}}=await supabase.auth.getSession();
  if(!session) return null;
  const out={companies:[],products:[],deliveries:[],invoices:[],expenses:[],staff:[],suppliers:[],cashEntries:[],stock:[],payments:[]};
  for(const [key,table] of Object.entries(TABLES)){
    const {data,error}=await supabase.from(table).select("*").order("created_at",{ascending:true});
    if(error) throw error;
    out[key]=(data||[]).map(row=>normalizeRow(key,row));
  }
  return out;
}
function normalizeRow(key,row){
  if(key==="companies") return {...row,id:row.id,name:row.name,contact:row.contact,phone:row.phone,terms:row.terms};
  if(key==="products") return {...row,id:row.id,name:row.name,unit:row.unit,price:Number(row.price||0)};
  if(key==="deliveries") return {...row,id:row.id,date:row.delivery_date,company:row.company,product:row.product,qty:Number(row.qty||0),amount:Number(row.amount||0),status:row.status};
  if(key==="invoices") return {...row,id:row.invoice_no||row.id,company:row.company,date:row.invoice_date,due:row.due_date,amount:Number(row.amount||0),status:row.status,vat:Number(row.vat||0),subtotal:Number(row.subtotal||0),notes:row.notes||"",lines:row.lines||[]};
  if(key==="expenses") return {...row,id:row.id,date:row.expense_date,category:row.category,description:row.description,amount:Number(row.amount||0)};
  if(key==="staff") return {...row,id:row.id,name:row.staff_name,date:row.wage_date,hours:Number(row.hours||0),rate:Number(row.rate||0),total:Number(row.total||0),status:row.status};
  if(key==="suppliers") return {...row,id:row.id,name:row.supplier_name,product:row.product,date:row.purchase_date,qty:Number(row.qty||0),price:Number(row.price||0)};
  if(key==="cashEntries") return {...row,id:row.id,date:row.entry_date,account:row.account,type:row.type,description:row.description,amount:Number(row.amount||0)};
  if(key==="stock") return {...row,id:row.id,product:row.product,unit:row.unit,qty:Number(row.qty||0),min:Number(row.min_qty||0),cost:Number(row.cost||0)};
  if(key==="payments") return {...row,id:row.id,invoice:row.invoice_no||row.invoice,company:row.company,date:row.payment_date,amount:Number(row.amount||0),method:row.method,reference:row.reference};
  return row;
}
function cloudRow(key,x){
  if(key==="companies") return {name:x.name,contact:x.contact,phone:x.phone,terms:x.terms};
  if(key==="products") return {name:x.name,unit:x.unit,price:x.price};
  if(key==="deliveries") return {delivery_date:x.date,company:x.company,product:x.product,qty:x.qty,amount:x.amount,status:x.status};
  if(key==="invoices") return {invoice_no:x.id,company:x.company,invoice_date:x.date,due_date:x.due,amount:x.amount,status:x.status,vat:x.vat||0,subtotal:x.subtotal||0,notes:x.notes||"",lines:x.lines||[]};
  if(key==="expenses") return {expense_date:x.date,category:x.category,description:x.description,amount:x.amount};
  if(key==="staff") return {staff_name:x.name,wage_date:x.date,hours:x.hours,rate:x.rate,status:x.status};
  if(key==="suppliers") return {supplier_name:x.name,product:x.product,purchase_date:x.date,qty:x.qty,price:x.price};
  if(key==="cashEntries") return {entry_date:x.date,account:x.account,type:x.type,description:x.description,amount:x.amount};
  if(key==="stock") return {product:x.product,unit:x.unit,qty:x.qty,min_qty:x.min,cost:x.cost};
  if(key==="payments") return {invoice_no:x.invoice,company:x.company,payment_date:x.date,amount:x.amount,method:x.method,reference:x.reference};
  return x;
}
async function cloudInsert(key,item){
  if(!supabase) return;
  const {error}=await supabase.from(TABLES[key]).insert(cloudRow(key,item));
  if(error) throw error;
}
async function cloudDelete(key,id){
  if(!supabase) return;
  // Invoice numbers are not UUIDs in the UI, so delete invoices by invoice_no.
  const col=key==="invoices"?"invoice_no":"id";
  const {error}=await supabase.from(TABLES[key]).delete().eq(col,id);
  if(error) throw error;
}

const initial = {
 companies:[
  {id:1,name:"Cafe Luna",contact:"Sarah",phone:"020 0000 1001",terms:"7 days"},
  {id:2,name:"Chambers",contact:"James",phone:"020 0000 1002",terms:"14 days"},
  {id:3,name:"Charlie",contact:"Mia",phone:"020 0000 1003",terms:"7 days"},
  {id:4,name:"Cross Box",contact:"Alex",phone:"020 0000 1004",terms:"30 days"}
 ],
 products:[
  {id:1,name:"White sourdough",unit:"loaf",price:4.5},
  {id:2,name:"Ciabatta",unit:"each",price:2.2},
  {id:3,name:"Simit",unit:"each",price:1.25},
  {id:4,name:"Burger bun",unit:"pack",price:4},
  {id:5,name:"Cinnamon roll",unit:"each",price:3},
  {id:6,name:"Croissant",unit:"each",price:2.5}
 ],
 deliveries:[
  {id:1,date:"2026-09-12",company:"Cafe Luna",product:"Simit",qty:20,amount:25,status:"Pending"},
  {id:2,date:"2026-09-12",company:"Cafe Luna",product:"White sourdough",qty:6,amount:27,status:"Paid"},
  {id:3,date:"2026-09-12",company:"Chambers",product:"Burger bun",qty:13,amount:52,status:"Pending"},
  {id:4,date:"2026-09-11",company:"Charlie",product:"Croissant",qty:18,amount:45,status:"Paid"},
  {id:5,date:"2026-09-11",company:"Cross Box",product:"Ciabatta",qty:12,amount:26.4,status:"Pending"}
 ],
 invoices:[
  {id:"INV-1001",company:"Cafe Luna",date:"2026-09-12",due:"2026-09-19",amount:52,status:"Pending"},
  {id:"INV-1000",company:"Charlie",date:"2026-09-11",due:"2026-09-18",amount:45,status:"Paid"}
 ],
 expenses:[
  {id:1,date:"2026-09-12",category:"Ingredients",description:"Flour",amount:180},
  {id:2,date:"2026-09-10",category:"Fuel",description:"Delivery van",amount:65}
 ],
 staff:[
  {id:1,name:"Deniz",date:"2026-09-12",hours:8,rate:14,total:112,status:"Cash"},
  {id:2,name:"Sam",date:"2026-09-12",hours:6,rate:13,total:78,status:"Bank"}
 ],
 suppliers:[
  {id:1,name:"London Foods",product:"Flour",date:"2026-09-10",qty:25,price:22.5},
  {id:2,name:"Fresh Dairy",product:"Butter",date:"2026-09-09",qty:10,price:39}
 ]
};

const money = n => new Intl.NumberFormat("en-GB",{style:"currency",currency:"GBP"}).format(Number(n||0));
const nav = [
 ["dashboard","Dashboard",LayoutDashboard],["deliveries","Deliveries",Truck],["companies","Companies",Building2],
 ["products","Products",Croissant],["invoices","Invoices",ReceiptText],["finance","Finance",WalletCards],
 ["staff","Staff Wages",Users],["suppliers","Suppliers",Package],["reports","Reports",BarChart3],["cash","Cash / Bank",WalletCards],["stock","Stock",Package],["statements","Statements",ReceiptText],["payments","Payments",WalletCards]
];

function load(){try{return JSON.parse(localStorage.getItem("bt-v2"))||initial}catch{return initial}}
function App(){
 const [db,setDb]=useState(()=>{
   const d=load();
   return {...d, cashEntries:d.cashEntries||[
     {id:1,date:"2026-09-13",account:"Cash",type:"In",description:"Till sales",amount:120},
     {id:2,date:"2026-09-13",account:"Bank",type:"Out",description:"Supplier payment",amount:80}
   ],stock:d.stock||[
     {id:1,product:"Flour",unit:"kg",qty:45,min:15,cost:0.72},
     {id:2,product:"Butter",unit:"kg",qty:12,min:5,cost:5.20},
     {id:3,product:"Chocolate",unit:"kg",qty:8,min:3,cost:8.50}
   ],payments:d.payments||[
     {id:1,invoice:"INV-1000",company:"Charlie",date:"2026-09-12",amount:45,method:"Bank",reference:"CH-001"}
   ]};
 });
 const [session,setSession]=useState(null);
 const [authOpen,setAuthOpen]=useState(false);
 const [authMode,setAuthMode]=useState("signin");
 const [authEmail,setAuthEmail]=useState("");
 const [authPassword,setAuthPassword]=useState("");
 const [authMsg,setAuthMsg]=useState("");

 React.useEffect(()=>{
   if(!supabase) return;
   supabase.auth.getSession().then(async({data})=>{
     setSession(data.session);
     if(data.session){ try{ const cloud=await loadCloud(); if(cloud) setDb(prev=>({...prev,...cloud})); }catch(e){ console.error(e); } }
   });
   const {data:listener}=supabase.auth.onAuthStateChange(async(_event,sess)=>{
     setSession(sess);
     if(sess){ try{ const cloud=await loadCloud(); if(cloud) setDb(prev=>({...prev,...cloud})); }catch(e){ console.error(e); } }
   });
   return ()=>listener.subscription.unsubscribe();
 },[]);
 const [page,setPage]=useState("dashboard"); const [open,setOpen]=useState(false);
 const [query,setQuery]=useState(""); const [modal,setModal]=useState(null);
 const [invoiceBuilder,setInvoiceBuilder]=useState(false);
 const persist=x=>{setDb(x);localStorage.setItem("bt-v2",JSON.stringify(x))};
 const title=nav.find(x=>x[0]===page)?.[1]||"Dashboard";
 const revenue=db.deliveries.reduce((a,x)=>a+x.amount,0), expenses=db.expenses.reduce((a,x)=>a+x.amount,0), wages=db.staff.reduce((a,x)=>a+x.total,0);
 const pending=db.invoices.filter(x=>x.status==="Pending").reduce((a,x)=>a+x.amount,0);
 const add=(type,item)=>persist({...db,[type]:[...db[type],{...item,id:item.id||Date.now()}]});
 const remove=(type,id)=>persist({...db,[type]:db[type].filter(x=>x.id!==id)});
 const exportData=()=>{const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([JSON.stringify(db,null,2)],{type:"application/json"}));a.download="bakerytrack-backup.json";a.click()};
 const filterRows=rows=>rows.filter(x=>Object.values(x).join(" ").toLowerCase().includes(query.toLowerCase()));
 return <div className="shell">
  <aside className={"sidebar "+(open?"open":"")}>
   <div className="brand"><div className="brandmark">B</div><div><b>BakeryTrack</b><small>PRO</small></div><button className="close" onClick={()=>setOpen(false)}><X/></button></div>
   <div className="workspace"><span className="avatar">CB</span><div><b>Cross Bakery</b><small>{cloudEnabled ? (session ? "Cloud account connected" : "Cloud ready · sign in") : "Local mode · cloud not configured"}</small></div><ChevronDown size={15}/></div>
   <nav>{nav.map(([id,label,Icon])=><button className={page===id?"active":""} onClick={()=>{setPage(id);setOpen(false)}} key={id}><Icon size={18}/><span>{label}</span></button>)}</nav>
   <div className="sidebar-foot"><div className="sync-dot"/> Local mode · ready for cloud sync</div>
  </aside>
  <main>
   <header className="topbar">
    <button className="mobile" onClick={()=>setOpen(true)}><Menu/></button>
    <div><div className="eyebrow">Workspace / {title}</div><h1>{title}</h1></div>
    <div className="head-actions">{cloudEnabled && (session ? <button className="secondary" onClick={async()=>{await signOut();setSession(null)}}>Sign out</button> : <button className="secondary" onClick={()=>setAuthOpen(true)}>Sign in</button>)}<div className="search"><Search size={16}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search..."/></div><button className="round"><Bell size={18}/></button><button className="primary" onClick={()=>setModal(page==="deliveries"?"delivery":page==="companies"?"company":page==="products"?"product":page==="invoices"?"invoice":page==="staff"?"staff":page==="suppliers"?"supplier":page==="cash"?"cash":page==="stock"?"stock":page==="payments"?"payment":"expense"}><Plus size={17}/> Add</button></div>
   </header>
   <section className="content">
    {page==="dashboard" && <Dashboard db={db} revenue={revenue} expenses={expenses} wages={wages} pending={pending} setPage={setPage}/>}
    {page==="deliveries" && <Table title="Delivery records" rows={filterRows(db.deliveries)} type="deliveries" cols={["date","company","product","qty","amount","status"]} remove={remove} money={money}/>}
    {page==="companies" && <Table title="Customers & companies" rows={filterRows(db.companies)} type="companies" cols={["name","contact","phone","terms"]} remove={remove}/>}
    {page==="products" && <Table title="Product catalogue" rows={filterRows(db.products)} type="products" cols={["name","unit","price"]} remove={remove} money={money}/>}
    {page==="invoices" && <><div className="panel"><div className="panel-head"><div><h3>Invoice centre</h3><small>Create a professional invoice with line items, VAT and payment terms.</small></div><button className="primary" onClick={()=>setInvoiceBuilder(true)}><Plus size={16}/> New invoice</button></div></div><Table title="Invoices" rows={filterRows(db.invoices)} type="invoices" cols={["id","company","date","due","amount","status"]} remove={remove} money={money}/></>}
    {page==="finance" && <Finance db={db} setModal={setModal} remove={remove} money={money}/>}
    {page==="staff" && <Table title="Staff wages" rows={filterRows(db.staff)} type="staff" cols={["name","date","hours","rate","total","status"]} remove={remove} money={money}/>}
    {page==="suppliers" && <Table title="Suppliers & purchases" rows={filterRows(db.suppliers)} type="suppliers" cols={["name","product","date","qty","price"]} remove={remove} money={money}/>}
    {page==="reports" && <Reports db={db} revenue={revenue} expenses={expenses} wages={wages} pending={pending}/>}
    {page==="cash" && <CashPage db={db} setModal={setModal} remove={remove} money={money}/>}
    {page==="stock" && <StockPage db={db} setModal={setModal} remove={remove} money={money}/>}
    {page==="statements" && <Statements db={db} money={money}/>}
    {page==="payments" && <PaymentsPage db={db} setModal={setModal} remove={remove} money={money}/>}
   </section>
  </main>
  {invoiceBuilder && <InvoiceBuilder db={db} close={()=>setInvoiceBuilder(false)} add={add} money={money}/>}
  {modal && <Modal type={modal} db={db} close={()=>setModal(null)} add={add}/>}
 </div>
}

function Dashboard({db,revenue,expenses,wages,pending,setPage}){
 const net=revenue-expenses-wages;
 return <><div className="welcome"><div><span className="pill blue">TODAY · 13 SEP 2026</span><h2>Good evening 👋</h2><p>Here is your bakery at a glance.</p></div><button className="secondary" onClick={()=>setPage("reports")}>View full report <BarChart3 size={16}/></button></div>
 <div className="stats">
  <Stat label="Sales" value={money(revenue)} note={`${db.deliveries.length} deliveries`} icon="£"/>
  <Stat label="Net profit" value={money(net)} note="after expenses & wages" icon="↗"/>
  <Stat label="Outstanding" value={money(pending)} note={`${db.invoices.filter(x=>x.status==="Pending").length} invoices`} icon="!" danger/>
  <Stat label="Deliveries" value={db.deliveries.length} note={`${db.deliveries.filter(x=>x.status==="Pending").length} pending`} icon="→"/>
 </div>
 <div className="columns">
  <div className="panel"><div className="panel-head"><div><h3>Recent deliveries</h3><small>Latest activity</small></div><button className="link" onClick={()=>setPage("deliveries")}>View all</button></div><MiniTable rows={db.deliveries.slice().reverse().slice(0,5)} money={money}/></div>
  <div className="panel"><div className="panel-head"><div><h3>Quick actions</h3><small>Common tasks</small></div></div><div className="quick"><button onClick={()=>setPage("deliveries")}><Truck/> New delivery</button><button onClick={()=>setPage("invoices")}><ReceiptText/> Invoice</button><button onClick={()=>setPage("companies")}><Building2/> Customer</button><button onClick={()=>setPage("finance")}><WalletCards/> Expense</button></div><div className="tip"><b>Next upgrade</b><br/>Connect Supabase to turn local records into secure cloud data with login and multi-device sync.</div></div>
 </div>
 <div className="panel"><div className="panel-head"><div><h3>Sales trend</h3><small>Recent recorded deliveries</small></div></div><Bars rows={db.deliveries.slice(-7)}/></div>
 </>;
}
function Stat({label,value,note,icon,danger}){return <div className="stat"><div className={"stat-icon "+(danger?"danger":"")}>{icon}</div><div><small>{label}</small><strong>{value}</strong><span>{note}</span></div></div>}
function MiniTable({rows,money}){return <div className="mini-table">{rows.map(x=><div className="row" key={x.id}><div><b>{x.company}</b><small>{x.product} · {x.qty}</small></div><b>{money(x.amount)}</b><Badge status={x.status}/></div>)}</div>}
function Bars({rows}){const max=Math.max(...rows.map(x=>x.amount),1);return <div className="bars">{rows.map((x,i)=><div className="bar-col" key={x.id}><small>{money(x.amount)}</small><div className="bar" style={{height:Math.max(18,(x.amount/max)*145)}}/><span>{x.company.slice(0,8)}</span></div>)}</div>}
function Badge({status}){return <span className={"badge "+String(status).toLowerCase()}>{status}</span>}
function Table({title,rows,type,cols,remove,money}){
 return <div className="panel"><div className="panel-head"><div><h3>{title}</h3><small>{rows.length} records</small></div></div><div className="table-scroll"><table><thead><tr>{cols.map(c=><th key={c}>{c.replace("_"," ")}</th>)}<th/></tr></thead><tbody>{rows.map(x=><tr key={x.id}>{cols.map(c=><td key={c}>{c==="amount"||c==="price"||c==="rate"||c==="total"?money(x[c]):c==="status"?<Badge status={x[c]}/>:x[c]}</td>)}<td><button className="icon-danger" onClick={()=>remove(type,x.id)} title="Delete"><Trash2 size={15}/></button></td></tr>)}{!rows.length&&<tr><td colSpan={cols.length+1} className="empty">No matching records.</td></tr>}</tbody></table></div></div>
}
function Finance({db,setModal,remove,money}){const income=db.deliveries.reduce((a,x)=>a+x.amount,0),exp=db.expenses.reduce((a,x)=>a+x.amount,0),w=db.staff.reduce((a,x)=>a+x.total,0);return <><div className="stats"><Stat label="Income" value={money(income)} note="deliveries"/><Stat label="Expenses" value={money(exp)} note="recorded costs"/><Stat label="Wages" value={money(w)} note="staff"/><Stat label="Net" value={money(income-exp-w)} note="operating result"/></div><div className="panel"><div className="panel-head"><div><h3>Expenses</h3><small>{db.expenses.length} records</small></div><button className="primary" onClick={()=>setModal("expense")}><Plus size={16}/> Add expense</button></div><Table rows={db.expenses} type="expenses" cols={["date","category","description","amount"]} remove={remove} money={money}/></div></>}
function Reports({db,revenue,expenses,wages,pending}){const companies={};db.deliveries.forEach(x=>companies[x.company]=(companies[x.company]||0)+x.amount);return <><div className="stats"><Stat label="Revenue" value={money(revenue)} note="all deliveries"/><Stat label="Costs" value={money(expenses+wages)} note="expenses + wages"/><Stat label="Net" value={money(revenue-expenses-wages)} note="current result"/><Stat label="Receivables" value={money(pending)} note="pending invoices"/></div><div className="panel"><div className="panel-head"><div><h3>Sales by customer</h3><small>Recorded delivery value</small></div><button className="secondary" onClick={()=>alert("Export is available from the dashboard in the next build.")}><Download size={16}/> Export</button></div><div className="rank-list">{Object.entries(companies).sort((a,b)=>b[1]-a[1]).map(([name,val])=><div className="rank" key={name}><b>{name}</b><div className="progress"><i style={{width:`${Math.min(100,val/Math.max(...Object.values(companies))*100)}%`}}/></div><strong>{money(val)}</strong></div>)}</div></div></>}

function InvoiceBuilder({db,close,add,money}){
 const today="2026-09-13";
 const [company,setCompany]=useState("");
 const [date,setDate]=useState(today);
 const [due,setDue]=useState("2026-09-20");
 const [vat,setVat]=useState(20);
 const [notes,setNotes]=useState("");
 const [lines,setLines]=useState([{product:"",qty:1,price:0}]);
 const update=(i,k,v)=>setLines(lines.map((x,n)=>n===i?{...x,[k]:v}:x));
 const choose=(i,v)=>{const p=db.products.find(x=>x.name===v);update(i,"product",v);if(p)update(i,"price",p.price)};
 const subtotal=lines.reduce((n,x)=>n+(Number(x.qty)||0)*(Number(x.price)||0),0);
 const vatAmount=subtotal*(Number(vat)||0)/100, total=subtotal+vatAmount;
 const save=()=>{
   if(!company || !lines.some(x=>x.product)) return alert("Please select a customer and at least one product.");
   const no="INV-"+String((db.invoices.length||0)+1001).padStart(4,"0");
   add("invoices",{id:no,company,date,due,amount:Number(total.toFixed(2)),status:"Pending",vat:Number(vat),subtotal:Number(subtotal.toFixed(2)),notes,lines});
   close();
 };
 const print=()=>window.print();
 return <div className="modal invoice-modal"><div className="invoice-card">
  <div className="invoice-toolbar"><div><span className="eyebrow">INVOICE BUILDER</span><h2>Create invoice</h2></div><div className="invoice-actions"><button className="secondary" onClick={print}><Download size={15}/> Print / PDF</button><button className="round" onClick={close}><X size={18}/></button></div></div>
  <div className="invoice-paper" id="invoice-print">
   <div className="invoice-top"><div><div className="invoice-brand">CROSS BAKERY</div><small>BakeryTrack Pro</small></div><div className="invoice-word">INVOICE</div></div>
   <div className="invoice-meta">
    <label>Bill to<select value={company} onChange={e=>setCompany(e.target.value)}><option value="">Select customer...</option>{db.companies.map(c=><option key={c.id}>{c.name}</option>)}</select></label>
    <label>Invoice date<input type="date" value={date} onChange={e=>setDate(e.target.value)}/></label>
    <label>Due date<input type="date" value={due} onChange={e=>setDue(e.target.value)}/></label>
   </div>
   <div className="line-head"><span>PRODUCT</span><span>QTY</span><span>PRICE</span><span>TOTAL</span><span/></div>
   {lines.map((x,i)=><div className="line-row" key={i}><select value={x.product} onChange={e=>choose(i,e.target.value)}><option value="">Select product...</option>{db.products.map(p=><option key={p.id}>{p.name}</option>)}</select><input type="number" min="0" step="0.01" value={x.qty} onChange={e=>update(i,"qty",e.target.value)}/><input type="number" min="0" step="0.01" value={x.price} onChange={e=>update(i,"price",e.target.value)}/><b>{money((Number(x.qty)||0)*(Number(x.price)||0))}</b><button className="icon-danger" onClick={()=>setLines(lines.filter((_,n)=>n!==i))}><Trash2 size={14}/></button></div>)}
   <button className="secondary add-line" onClick={()=>setLines([...lines,{product:"",qty:1,price:0}])}><Plus size={14}/> Add line</button>
   <div className="invoice-bottom"><div><label>Notes<textarea value={notes} onChange={e=>setNotes(e.target.value)} placeholder="Payment details, thank you message..."/></label></div><div className="totals"><div>Subtotal <b>{money(subtotal)}</b></div><div>VAT <span><input className="vat-input" type="number" min="0" step="0.1" value={vat} onChange={e=>setVat(e.target.value)}/> %</span><b>{money(vatAmount)}</b></div><div className="grand">Total <b>{money(total)}</b></div></div></div>
  </div>
  <div className="modal-actions"><button className="secondary" onClick={close}>Cancel</button><button className="primary" onClick={save}>Save invoice</button></div>
 </div></div>
}

function Modal({type,db,close,add}){
 const defs={delivery:["Delivery","deliveries",["date","company","product","qty","amount","status"]],company:["Company","companies",["name","contact","phone","terms"]],product:["Product","products",["name","unit","price"]],invoice:["Invoice","invoices",["id","company","date","due","amount","status"]],expense:["Expense","expenses",["date","category","description","amount"]],staff:["Staff wage","staff",["name","date","hours","rate","status"]],supplier:["Supplier purchase","suppliers",["name","product","date","qty","price"]],cash:["Cash / bank entry","cashEntries",["date","account","type","description","amount"]],stock:["Stock item","stock",["product","unit","qty","min","cost"]],payment:["Payment","payments",["invoice","company","date","amount","method","reference"]]};
 const [title,key,fields]=defs[type]; const [form,setForm]=useState({status:"Pending",method:"Bank",account:"Cash",type:"In",date:"2026-09-13",due:"2026-09-20",terms:"7 days",unit:"each",category:"Ingredients"});
 const set=(k,v)=>setForm({...form,[k]:v});
 const submit=e=>{e.preventDefault();const f={...form};["qty","amount","price","hours","rate"].forEach(k=>{if(f[k]!==undefined)f[k]=Number(f[k])});if(type==="staff")f.total=f.hours*f.rate;add(key,f);close()};
 return <div className="modal"><form className="modal-card" onSubmit={submit}><div className="modal-head"><div><span className="eyebrow">NEW RECORD</span><h2>Add {title}</h2></div><button type="button" className="round" onClick={close}><X size={18}/></button></div><div className="form-grid">{fields.map(k=><label key={k}>{k.replace("_"," ")}{(k==="company"&&type!=="company")||k==="product"&&type==="delivery"||k==="invoice"&&type==="payment"?<select value={form[k]||""} onChange={e=>{set(k,e.target.value); if(k==="invoice"){const inv=db.invoices.find(x=>x.id===e.target.value); if(inv)setForm({...form,invoice:e.target.value,company:inv.company,amount:inv.amount})}}} required><option value="">Select...</option>{(k==="company"?db.companies.map(x=>x.name):k==="invoice"?db.invoices.map(x=>x.id):db.products.map(x=>x.name)).map(v=><option key={v}>{v}</option>)}</select>:k==="method"?<select value={form[k]||"Bank"} onChange={e=>set(k,e.target.value)}><option>Bank</option><option>Cash</option><option>Card</option><option>Transfer</option></select>:k==="account"?<select value={form[k]||"Cash"} onChange={e=>set(k,e.target.value)}><option>Cash</option><option>Bank</option><option>Till</option></select>:k==="type"?<select value={form[k]||"In"} onChange={e=>set(k,e.target.value)}><option>In</option><option>Out</option></select>:k==="status"?<select value={form[k]} onChange={e=>set(k,e.target.value)}><option>Pending</option><option>Paid</option></select>:<input required type={["date","due"].includes(k)?"date":["qty","amount","price","hours","rate"].includes(k)?"number":"text"} step={["qty","amount","price","hours","rate"].includes(k)?"0.01":undefined} value={form[k]||""} onChange={e=>set(k,e.target.value)}/>}</label>)}</div><div className="modal-actions"><button type="button" className="secondary" onClick={close}>Cancel</button><button className="primary">Save record</button></div></form></div>
}

function CashPage({db,setModal,remove,money}){
 const balance=a=>db.cashEntries.filter(x=>x.account===a).reduce((n,x)=>n+(x.type==="In"?x.amount:-x.amount),0);
 return <><div className="stats"><Stat label="Cash" value={money(balance("Cash"))} note="current balance"/><Stat label="Bank" value={money(balance("Bank"))} note="current balance"/><Stat label="Till" value={money(balance("Till"))} note="current balance"/><Stat label="Total" value={money(["Cash","Bank","Till"].reduce((n,a)=>n+balance(a),0))} note="all accounts"/></div>
 <div className="panel"><div className="panel-head"><div><h3>Cash / Bank / Till ledger</h3><small>Money in and out</small></div><button className="primary" onClick={()=>setModal("cash")}><Plus size={16}/> Add entry</button></div>
 <div className="table-scroll"><table><thead><tr><th>Date</th><th>Account</th><th>Type</th><th>Description</th><th>Amount</th><th/></tr></thead><tbody>{db.cashEntries.slice().reverse().map(x=><tr key={x.id}><td>{x.date}</td><td>{x.account}</td><td><Badge status={x.type==="In"?"Paid":"Pending"}/></td><td>{x.description}</td><td className={x.type==="In"?"success":"danger"}>{x.type==="In"?"+":"-"}{money(x.amount)}</td><td><button className="icon-danger" onClick={()=>remove("cashEntries",x.id)}><Trash2 size={15}/></button></td></tr>)}</tbody></table></div></div></>
}
function StockPage({db,setModal,remove,money}){
 const low=db.stock.filter(x=>x.qty<=x.min);
 return <><div className="stats"><Stat label="Stock items" value={db.stock.length} note="tracked items"/><Stat label="Low stock" value={low.length} note="needs attention" danger/><Stat label="Stock value" value={money(db.stock.reduce((n,x)=>n+x.qty*x.cost,0))} note="at purchase cost"/><Stat label="Products" value={db.products.length} note="catalogue"/></div>
 {low.length>0&&<div className="danger-box">⚠️ Low stock: {low.map(x=>x.product).join(", ")}</div>}
 <div className="panel" style={{marginTop:14}}><div className="panel-head"><div><h3>Inventory</h3><small>Quantity, minimum and cost</small></div><button className="primary" onClick={()=>setModal("stock")}><Plus size={16}/> Add stock item</button></div>
 <div className="table-scroll"><table><thead><tr><th>Product</th><th>Unit</th><th>Qty</th><th>Minimum</th><th>Cost</th><th>Value</th><th/></tr></thead><tbody>{db.stock.map(x=><tr key={x.id}><td>{x.product}</td><td>{x.unit}</td><td>{x.qty}</td><td>{x.min}</td><td>{money(x.cost)}</td><td>{money(x.qty*x.cost)}</td><td><button className="icon-danger" onClick={()=>remove("stock",x.id)}><Trash2 size={15}/></button></td></tr>)}</tbody></table></div></div></>
}

function PaymentsPage({db,setModal,remove,money}){
 const paid=db.payments.reduce((n,x)=>n+x.amount,0);
 const outstanding=db.invoices.reduce((n,x)=>n+x.amount,0)-paid;
 return <><div className="stats"><Stat label="Received" value={money(paid)} note="recorded payments"/><Stat label="Outstanding" value={money(Math.max(0,outstanding))} note="invoices less payments" danger/><Stat label="Invoices" value={db.invoices.length} note="all invoices"/><Stat label="Payments" value={db.payments.length} note="transactions"/></div>
 <div className="panel"><div className="panel-head"><div><h3>Payment ledger</h3><small>Record customer payments against invoices</small></div><button className="primary" onClick={()=>setModal("payment")}><Plus size={16}/> Record payment</button></div>
 <div className="table-scroll"><table><thead><tr><th>Date</th><th>Invoice</th><th>Customer</th><th>Method</th><th>Reference</th><th>Amount</th><th/></tr></thead><tbody>{db.payments.slice().reverse().map(x=><tr key={x.id}><td>{x.date}</td><td>{x.invoice}</td><td>{x.company}</td><td>{x.method}</td><td>{x.reference}</td><td className="success">+{money(x.amount)}</td><td><button className="icon-danger" onClick={()=>remove("payments",x.id)}><Trash2 size={15}/></button></td></tr>)}</tbody></table></div></div></>
}
function Statements({db,money}){
 const names=[...new Set([...db.invoices.map(x=>x.company),...db.payments.map(x=>x.company)])];
 return <div className="panel"><div className="panel-head"><div><h3>Customer statements</h3><small>Invoices, payments and current balance</small></div></div>
 <div className="statement-list">{names.map(name=>{const inv=db.invoices.filter(x=>x.company===name);const pay=db.payments.filter(x=>x.company===name);const billed=inv.reduce((n,x)=>n+x.amount,0),received=pay.reduce((n,x)=>n+x.amount,0),due=Math.max(0,billed-received);return <div className="statement-card" key={name}><div><b>{name}</b><small>{inv.length} invoices · {pay.length} payments</small></div><div className="statement-numbers"><span>Billed <b>{money(billed)}</b></span><span>Paid <b className="success">{money(received)}</b></span><strong className={due?"danger":"success"}>{due?money(due)+" due":"PAID"}</strong></div></div>})}</div>
 {names.length===0&&<div className="empty">No customer transactions yet.</div>}
 </div>
}
function Modal({type,db,close,add}){
 const defs={delivery:["Delivery","deliveries",["date","company","product","qty","amount","status"]],company:["Company","companies",["name","contact","phone","terms"]],product:["Product","products",["name","unit","price"]],invoice:["Invoice","invoices",["id","company","date","due","amount","status"]],expense:["Expense","expenses",["date","category","description","amount"]],staff:["Staff wage","staff",["name","date","hours","rate","status"]],supplier:["Supplier purchase","suppliers",["name","product","date","qty","price"]],cash:["Cash / bank entry","cashEntries",["date","account","type","description","amount"]],stock:["Stock item","stock",["product","unit","qty","min","cost"]],payment:["Payment","payments",["invoice","company","date","amount","method","reference"]]};
 const [title,key,fields]=defs[type]; const [form,setForm]=useState({status:"Pending",method:"Bank",account:"Cash",type:"In",date:"2026-09-13",due:"2026-09-20",terms:"7 days",unit:"each",category:"Ingredients"});
 const set=(k,v)=>setForm({...form,[k]:v});
 const submit=e=>{e.preventDefault();const f={...form};["qty","amount","price","hours","rate"].forEach(k=>{if(f[k]!==undefined)f[k]=Number(f[k])});if(type==="staff")f.total=f.hours*f.rate;add(key,f);close()};
 return <div className="modal"><form className="modal-card" onSubmit={submit}><div className="modal-head"><div><span className="eyebrow">NEW RECORD</span><h2>Add {title}</h2></div><button type="button" className="round" onClick={close}><X size={18}/></button></div><div className="form-grid">{fields.map(k=><label key={k}>{k.replace("_"," ")}{(k==="company"&&type!=="company")||k==="product"&&type==="delivery"||k==="invoice"&&type==="payment"?<select value={form[k]||""} onChange={e=>{set(k,e.target.value); if(k==="invoice"){const inv=db.invoices.find(x=>x.id===e.target.value); if(inv)setForm({...form,invoice:e.target.value,company:inv.company,amount:inv.amount})}}} required><option value="">Select...</option>{(k==="company"?db.companies.map(x=>x.name):k==="invoice"?db.invoices.map(x=>x.id):db.products.map(x=>x.name)).map(v=><option key={v}>{v}</option>)}</select>:k==="method"?<select value={form[k]||"Bank"} onChange={e=>set(k,e.target.value)}><option>Bank</option><option>Cash</option><option>Card</option><option>Transfer</option></select>:k==="account"?<select value={form[k]||"Cash"} onChange={e=>set(k,e.target.value)}><option>Cash</option><option>Bank</option><option>Till</option></select>:k==="type"?<select value={form[k]||"In"} onChange={e=>set(k,e.target.value)}><option>In</option><option>Out</option></select>:k==="status"?<select value={form[k]} onChange={e=>set(k,e.target.value)}><option>Pending</option><option>Paid</option></select>:<input required type={["date","due"].includes(k)?"date":["qty","amount","price","hours","rate"].includes(k)?"number":"text"} step={["qty","amount","price","hours","rate"].includes(k)?"0.01":undefined} value={form[k]||""} onChange={e=>set(k,e.target.value)}/>}</label>)}</div><div className="modal-actions"><button type="button" className="secondary" onClick={close}>Cancel</button><button className="primary">Save record</button></div></form></div>
}

function CashPage({db,setModal,remove,money}){
 const balance=a=>db.cashEntries.filter(x=>x.account===a).reduce((n,x)=>n+(x.type==="In"?x.amount:-x.amount),0);
 return <><div className="stats"><Stat label="Cash" value={money(balance("Cash"))} note="current balance"/><Stat label="Bank" value={money(balance("Bank"))} note="current balance"/><Stat label="Till" value={money(balance("Till"))} note="current balance"/><Stat label="Total" value={money(["Cash","Bank","Till"].reduce((n,a)=>n+balance(a),0))} note="all accounts"/></div>
 <div className="panel"><div className="panel-head"><div><h3>Cash / Bank / Till ledger</h3><small>Money in and out</small></div><button className="primary" onClick={()=>setModal("cash")}><Plus size={16}/> Add entry</button></div>
 <div className="table-scroll"><table><thead><tr><th>Date</th><th>Account</th><th>Type</th><th>Description</th><th>Amount</th><th/></tr></thead><tbody>{db.cashEntries.slice().reverse().map(x=><tr key={x.id}><td>{x.date}</td><td>{x.account}</td><td><Badge status={x.type==="In"?"Paid":"Pending"}/></td><td>{x.description}</td><td className={x.type==="In"?"success":"danger"}>{x.type==="In"?"+":"-"}{money(x.amount)}</td><td><button className="icon-danger" onClick={()=>remove("cashEntries",x.id)}><Trash2 size={15}/></button></td></tr>)}</tbody></table></div></div></>
}
function StockPage({db,setModal,remove,money}){
 const low=db.stock.filter(x=>x.qty<=x.min);
 return <><div className="stats"><Stat label="Stock items" value={db.stock.length} note="tracked items"/><Stat label="Low stock" value={low.length} note="needs attention" danger/><Stat label="Stock value" value={money(db.stock.reduce((n,x)=>n+x.qty*x.cost,0))} note="at purchase cost"/><Stat label="Products" value={db.products.length} note="catalogue"/></div>
 {low.length>0&&<div className="danger-box">⚠️ Low stock: {low.map(x=>x.product).join(", ")}</div>}
 <div className="panel" style={{marginTop:14}}><div className="panel-head"><div><h3>Inventory</h3><small>Quantity, minimum and cost</small></div><button className="primary" onClick={()=>setModal("stock")}><Plus size={16}/> Add stock item</button></div>
 <div className="table-scroll"><table><thead><tr><th>Product</th><th>Unit</th><th>Qty</th><th>Minimum</th><th>Cost</th><th>Value</th><th/></tr></thead><tbody>{db.stock.map(x=><tr key={x.id}><td>{x.product}</td><td>{x.unit}</td><td>{x.qty}</td><td>{x.min}</td><td>{money(x.cost)}</td><td>{money(x.qty*x.cost)}</td><td><button className="icon-danger" onClick={()=>remove("stock",x.id)}><Trash2 size={15}/></button></td></tr>)}</tbody></table></div></div></>
}

function PaymentsPage({db,setModal,remove,money}){
 const paid=db.payments.reduce((n,x)=>n+x.amount,0);
 const outstanding=db.invoices.reduce((n,x)=>n+x.amount,0)-paid;
 return <><div className="stats"><Stat label="Received" value={money(paid)} note="recorded payments"/><Stat label="Outstanding" value={money(Math.max(0,outstanding))} note="invoices less payments" danger/><Stat label="Invoices" value={db.invoices.length} note="all invoices"/><Stat label="Payments" value={db.payments.length} note="transactions"/></div>
 <div className="panel"><div className="panel-head"><div><h3>Payment ledger</h3><small>Record customer payments against invoices</small></div><button className="primary" onClick={()=>setModal("payment")}><Plus size={16}/> Record payment</button></div>
 <div className="table-scroll"><table><thead><tr><th>Date</th><th>Invoice</th><th>Customer</th><th>Method</th><th>Reference</th><th>Amount</th><th/></tr></thead><tbody>{db.payments.slice().reverse().map(x=><tr key={x.id}><td>{x.date}</td><td>{x.invoice}</td><td>{x.company}</td><td>{x.method}</td><td>{x.reference}</td><td className="success">+{money(x.amount)}</td><td><button className="icon-danger" onClick={()=>remove("payments",x.id)}><Trash2 size={15}/></button></td></tr>)}</tbody></table></div></div></>
}
function Statements({db,money}){
 const names=[...new Set(db.invoices.map(x=>x.company))];
 return <div className="panel"><div className="panel-head"><div><h3>Customer statements</h3><small>Invoice balances by customer</small></div></div>
 <div className="rank-list">{names.map(name=>{const rows=db.invoices.filter(x=>x.company===name);const total=rows.reduce((n,x)=>n+x.amount,0),paid=rows.filter(x=>x.status==="Paid").reduce((n,x)=>n+x.amount,0);return <div className="rank" key={name}><b>{name}</b><div className="progress"><i style={{width:`${total?paid/total*100:0}%`}}/></div><strong>{money(total-paid)} due</strong></div>})}</div>
 {names.length===0&&<div className="empty">No invoices yet.</div>}
 <div className="tip" style={{marginTop:16}}><b>PDF invoices</b><br/>The next invoice builder can generate a print-ready A4 invoice and customer statement from these records.</div>
 </div>
}
createRoot(document.getElementById("root")).render(<App/>);