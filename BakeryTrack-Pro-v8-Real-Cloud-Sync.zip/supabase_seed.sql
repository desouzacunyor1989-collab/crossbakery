-- Optional starter data after creating your user.
-- Replace YOUR_USER_UUID with the id from auth.users.
-- This is intentionally separate from the schema so it is safe to run only when wanted.

-- Example:
-- insert into public.products (user_id,name,unit,price)
-- values ('YOUR_USER_UUID','Simit','each',1.25),
--        ('YOUR_USER_UUID','Croissant','each',2.50),
--        ('YOUR_USER_UUID','Burger bun','pack',4.00);
