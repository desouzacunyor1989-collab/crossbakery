import { createClient } from "@supabase/supabase-js";

const url = import.meta.env.VITE_SUPABASE_URL;
const key = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = (url && key) ? createClient(url, key) : null;
export const cloudEnabled = !!supabase;

export async function signIn(email, password) {
  if (!supabase) throw new Error("Supabase is not configured. Add VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY.");
  return supabase.auth.signInWithPassword({ email, password });
}
export async function signUp(email, password) {
  if (!supabase) throw new Error("Supabase is not configured.");
  return supabase.auth.signUp({ email, password });
}
export async function signOut() {
  if (!supabase) return;
  return supabase.auth.signOut();
}
