-- BakeryTrack Pro cloud database
-- Run this in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.companies (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null default auth.uid(),
  name text not null, contact text, phone text, terms text default '7 days',
  created_at timestamptz default now()
);
create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null default auth.uid(),
  name text not null, unit text default 'each', price numeric(12,2) default 0,
  created_at timestamptz default now()
);
create table if not exists public.deliveries (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null default auth.uid(),
  delivery_date date not null default current_date, company text not null,
  product text not null, qty numeric(12,2) not null default 0,
  amount numeric(12,2) not null default 0, status text not null default 'Pending',
  created_at timestamptz default now()
);
create table if not exists public.invoices (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null default auth.uid(),
  invoice_no text not null, company text not null, invoice_date date default current_date,
  due_date date, amount numeric(12,2) default 0, status text default 'Pending',
  created_at timestamptz default now()
);
create table if not exists public.expenses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null default auth.uid(),
  expense_date date default current_date, category text, description text,
  amount numeric(12,2) default 0, created_at timestamptz default now()
);
create table if not exists public.staff_wages (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null default auth.uid(),
  staff_name text not null, wage_date date default current_date,
  hours numeric(8,2) default 0, rate numeric(10,2) default 0,
  total numeric(12,2) generated always as (hours * rate) stored,
  status text default 'Cash', created_at timestamptz default now()
);
create table if not exists public.suppliers (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null default auth.uid(),
  supplier_name text not null, product text, purchase_date date default current_date,
  qty numeric(12,2) default 0, price numeric(12,2) default 0, created_at timestamptz default now()
);

alter table public.companies enable row level security;
alter table public.products enable row level security;
alter table public.deliveries enable row level security;
alter table public.invoices enable row level security;
alter table public.expenses enable row level security;
alter table public.staff_wages enable row level security;
alter table public.suppliers enable row level security;

do $$ declare t text; begin
 foreach t in array array['companies','products','deliveries','invoices','expenses','staff_wages','suppliers'] loop
   execute format('drop policy if exists "own_%s" on public.%s',t,t);
   execute format('create policy "own_%s" on public.%s for all using (user_id=auth.uid()) with check (user_id=auth.uid())',t,t);
 end loop;
end $$;

-- v8 additional tables
create table if not exists public.cash_entries (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null default auth.uid(),
  entry_date date default current_date, account text not null, type text not null,
  description text, amount numeric(12,2) default 0, created_at timestamptz default now()
);
create table if not exists public.stock (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null default auth.uid(),
  product text not null, unit text default 'each', qty numeric(12,2) default 0,
  min_qty numeric(12,2) default 0, cost numeric(12,2) default 0, created_at timestamptz default now()
);
create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null default auth.uid(),
  invoice_no text, company text not null, payment_date date default current_date,
  amount numeric(12,2) default 0, method text default 'Bank', reference text, created_at timestamptz default now()
);
alter table public.cash_entries enable row level security;
alter table public.stock enable row level security;
alter table public.payments enable row level security;
do $$ declare t text; begin
 foreach t in array array['cash_entries','stock','payments'] loop
   execute format('drop policy if exists "own_%s" on public.%s',t,t);
   execute format('create policy "own_%s" on public.%s for all using (user_id=auth.uid()) with check (user_id=auth.uid())',t,t);
 end loop;
end $$;

-- Optional invoice metadata columns used by v8.
alter table public.invoices add column if not exists vat numeric(8,2) default 0;
alter table public.invoices add column if not exists subtotal numeric(12,2) default 0;
alter table public.invoices add column if not exists notes text;
alter table public.invoices add column if not exists lines jsonb default '[]'::jsonb;
