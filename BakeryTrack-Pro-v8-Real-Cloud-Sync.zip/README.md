# BakeryTrack Pro v2

A cleaner, Base44-independent bakery management starter based on the supplied BakeryTrack workflow.

## Run locally
1. Install Node.js 18+.
2. In this folder run `npm install`.
3. Run `npm run dev`.
4. Open the local Vite address.

The app works immediately in **local mode** using browser storage.

## Cloud mode
A Supabase schema is included in `supabase_schema.sql`, with row-level security so each signed-in user only sees their own records. The next implementation step is wiring the existing UI to Supabase and adding email/password authentication.

## v4 modules
Dashboard, Deliveries, Companies, Products, Invoices, Finance, Staff Wages, Suppliers, Reports, Cash/Bank/Till, Stock and Customer Statements.
The v4 build adds a money ledger, low-stock alerts, stock valuation and customer receivable summaries.

## Planned production features
- Secure Supabase authentication
- Multi-device sync
- Customer statements
- PDF invoices
- VAT settings
- Cash / Bank / Till reconciliation
- Stock and purchase orders
- Delivery routes
- Recurring orders
- CSV/PDF exports
- PWA install and iPhone home-screen support


## v3 cloud connection
1. Create a Supabase project.
2. Open SQL Editor and run `supabase_schema.sql`.
3. Create an `.env` file from `.env.example`.
4. Put your Supabase Project URL and anon/publishable key into the two VITE variables.
5. Run `npm install` and `npm run dev`.

The included `src/supabase.js` detects whether Supabase is configured. The current UI remains usable in local mode until the cloud wiring is completed. The SQL includes row-level security so records are isolated by `auth.uid()`.

### Important
Never put a Supabase service-role/secret key in the browser app. Only use the public anon/publishable key client-side.


## Recommended next step
Build the invoice editor with line items, VAT rate, payment terms, A4 print/PDF output and customer statements, then wire every module to Supabase repositories.


## v5 Invoice Builder
- Customer selection
- Product line items
- Quantity and price editing
- Automatic subtotal
- Configurable VAT percentage
- Automatic total
- Due date and notes
- Print / Save as PDF via browser print dialog
- Saved invoice records retain line items for future PDF/statement integration


## v6 customer finance flow
- Payment ledger with Bank/Cash/Card/Transfer methods
- Payments linked to invoice number and customer
- Customer statements now calculate billed, paid and due
- Outstanding receivables use recorded payments


## v7 iPhone / PWA
BakeryTrack Pro is now installable as a Progressive Web App:
- `manifest.webmanifest`
- App icons
- Service worker with offline shell caching
- Standalone mobile display
- iPhone Home Screen instructions in the UI

### iPhone install
Deploy the Vite build to an HTTPS host, open it in Safari, tap Share, then **Add to Home Screen**.

### Supabase next wiring
The client and RLS schema are already included. Add the two VITE environment variables, then connect repository functions to the tables for true multi-device synchronization.


## v8 real cloud sync
When Supabase is configured and a user is signed in, the app loads records from Supabase and writes new records/deletions to the cloud. Local browser storage remains as a fallback/cache.

Run the updated `supabase_schema.sql` in Supabase SQL Editor before using the new Cash/Stock/Payments cloud tables.

**Security:** the SQL uses `auth.uid()` row-level security. Keep the service-role/secret key out of the browser; use only the public anon/publishable key in Vite.
